function changeBackground(){
    const colors=["#f6d365","#fda085","#a1c4fd","#c2e9fb","#d4fc79"];
    document.body.style.backgroundColor=colors[Math.floor(Math.random()*colors.length)];
  }
  