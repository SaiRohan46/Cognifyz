function showMessage() {
    const messageBox = document.getElementById("messageBox");
    messageBox.style.display = "block";
    messageBox.innerHTML = "Thank you for learning more about Sass styling!";
  }
  